export interface Url {
    url: string;
    width?: number;
    height?: number;
}
