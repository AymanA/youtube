export interface VideoId {
    videoId: string;
    kind: string;
}
