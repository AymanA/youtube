export interface ChannelId {
    channelId: string;
    kind: string;
}
