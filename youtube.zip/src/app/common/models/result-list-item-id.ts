export interface ResultListItemId<T> {
    id: T;
    kind;
}
