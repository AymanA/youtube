export interface Localized {
    title: string;
    description: string;
}
