export interface PageInfo {
    resultsPerPage: number;
    totalResults: number;
}
