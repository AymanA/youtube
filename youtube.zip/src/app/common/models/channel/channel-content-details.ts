import { RelatedPlaylists } from './related-playlists';

export interface ChannelContentDetails {
    relatedPlaylists: RelatedPlaylists;
}
