export interface ChannelStatistics {
    commentCount: string;
    hiddenSubscriberCount: boolean;
    subscriberCount: string;
    videoCount: string;
    viewCount: string;
}
