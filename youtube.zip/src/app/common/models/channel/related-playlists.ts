export interface RelatedPlaylists {
    uploads: string;
    watchHistory: string;
    watchLater: string;

}
